
export class VehicleStatus {
  vehicleId: string;
  status: string;
}