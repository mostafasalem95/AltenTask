export class Vehicle {
	id: string;
	regNr: string;
	status: string;
}